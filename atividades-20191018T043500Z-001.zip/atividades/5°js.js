
function Nome() {
	if (document.getElementById("nome").value.length <=255 && document.getElementById("nome").value.length > 0 && document.getElementById("nome").value.indexOf("carro") == -1 && document.getElementById("nome").value.indexOf("macarrão") == -1){
	document.getElementById("errNome").innerHTML = "";
	return true;
	} else{
	document.getElementById("errNome").innerHTML = "o nome excedeu o limite";
	return false;
	}
}
function Lat(){
	if(parseFloat(document.getElementById("latitude").value) <= 90 && parseFloat(document.getElementById("latitude").value) >= -90 ){
	document.getElementById("errLat").innerHTML = "";
	return true;
	} else{
		document.getElementById("errLat").innerHTML = "Numeração excedida";
		return false;
	}
}
function Long(){
	if(parseFloat(document.getElementById("longitude").value)  <= 180 && parseFloat(document.getElementById("longitude").value) >= -180) {
		document.getElementById("errLong").innerHTML = "";
		return true;
	}else{
		document.getElementById("errLong").innerHTML = " Numeração excedida ";
		return false;
	}
}
function Des(){
	if(document.getElementById("descricao").value.length <=2000 && document.getElementById("descricao").value.length > 0){
		document.getElementById("errdes").innerHTML = "";
		return true;
	}else{
		document.getElementById("errdes").innerHTML = " numero de caracteres excedido ";
		return false;
	}
}
function Validar() {
	if (Nome() == true && Lat() == true && Long() == true && Des() == true) {
		document.getElementById("mss").innerHTML = "salvo com sucesso";
		document.getElementById("nome").value ="";
		document.getElementById("latitude").value ="";
		document.getElementById("longitude").value ="";
		document.getElementById("descricao").value ="";
		return true;
	} else {
		document.getElementById("mss").innerHTML = "";
		return false;
		
	}
}